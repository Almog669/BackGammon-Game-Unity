﻿//using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SC_GameLogic : MonoBehaviour
{
    private Dictionary<string, GameObject> UnityObjects;
    public SC_GlobalEnums.Screens CurrentScreen;
    public SC_GlobalEnums.Screens PrevioustScreen;
    //public AudioSource audiosource;
    private float MusicVolume = 1f;

    #region Singleton
    static SC_GameLogic instance;
    public static SC_GameLogic Instance
    {
        get
        {
            if (instance == null)
                instance = GameObject.Find("SC_GameLogic").GetComponent<SC_GameLogic>();
            return instance;
        }
    }
    #endregion

    #region MonoBehavior
    void Awake() {  Debug.Log("Awake");Init(); }
  //  void Update() { audiosource.volume = MusicVolume; }
    public void UpdateVolume(float volume) { MusicVolume = volume; }
    #endregion

    #region SC_Controller
    public void Btn_start()
    {
        ChangeScreen(SC_GlobalEnums.Screens.Loading);
    }

    public void Btn_Loading_Back()
    {
        ChangeScreen(PrevioustScreen);
    }

    public void Btn_MultiPlayer_Back()
    {
        ChangeScreen(SC_GlobalEnums.Screens.MainMenu);
    }

    public void Btn_Multi_Player()
    {
        ChangeScreen(SC_GlobalEnums.Screens.MultiPlayer);
    }

    public void Slider_MultiPlayer()
    {
        UnityObjects["Txt_BetValue"].GetComponent<Text>().text = UnityObjects["Slider_MultiPlayer"].GetComponent<Slider>().value.ToString()+"$";
    }

    public void Btn_StartGame()
    {
        ChangeScreen(SC_GlobalEnums.Screens.Loading);
    }

    public void Btn_Options()
    {
        ChangeScreen(SC_GlobalEnums.Screens.Options);
    }

    public void Btn_StudentInfo()
    {
        ChangeScreen(SC_GlobalEnums.Screens.StudentInfo);
    }

    public void Btn_LinktoSite()
    {
        Application.OpenURL("https://github.com/Almog669");
    }

    #endregion

    #region Logic
    private void Init()
    {
        CurrentScreen = SC_GlobalEnums.Screens.MainMenu ;
        PrevioustScreen = SC_GlobalEnums.Screens.MainMenu;
        UnityObjects = new Dictionary<string, GameObject>();
        GameObject[] _obj = GameObject.FindGameObjectsWithTag("GameObject");
        foreach (GameObject g in _obj)
            UnityObjects.Add(g.name, g);
        UnityObjects["Screen_Loading"].SetActive(false);
        UnityObjects["Screen_MultiPlayer"].SetActive(false);
        UnityObjects["Screen_Options"].SetActive(false);
        UnityObjects["Screen_StudentInfo"].SetActive(false);
        Debug.Log(UnityObjects.Count);
    }

    private void ChangeScreen(SC_GlobalEnums.Screens Screen)
    {
        UnityObjects["Screen_"+CurrentScreen].SetActive(false);
        UnityObjects["Screen_" + Screen].SetActive(true);
        PrevioustScreen = CurrentScreen;
        CurrentScreen = Screen; 
    }


    #endregion
}




