﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SC_Controller : MonoBehaviour
{

    
    public void Btn_start(){SC_GameLogic.Instance.Btn_start();}
    public void Btn_Loading_Back(){  SC_GameLogic.Instance.Btn_Loading_Back(); }
    public void Btn_Multi_Player() { SC_GameLogic.Instance.Btn_Multi_Player(); }
    public void Slider_MultiPlayer() { SC_GameLogic.Instance.Slider_MultiPlayer(); }
    public void Btn_MultiPlayer_Back() { SC_GameLogic.Instance.Btn_MultiPlayer_Back(); }
    public void Btn_Options() { SC_GameLogic.Instance.Btn_Options(); }
    public void Btn_StartGame() { SC_GameLogic.Instance.Btn_StartGame(); }
    public void Btn_StudentInfo() { SC_GameLogic.Instance.Btn_StudentInfo(); }
    public void Btn_LinktoSite() { SC_GameLogic.Instance.Btn_LinktoSite(); }
}
