﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SC_CubeLogic : MonoBehaviour
{
    int max = 5, min = -5, x, y, z;
    public float speed = 0.01f;
    int isclicked = 1;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        GameObject.Find("Time_text").GetComponent<TextMesh>().text = ((int)Time.time).ToString();
        if(isclicked==1)
        {
            Vector3 _pos = transform.position;
            transform.position = new Vector3(_pos.x + speed, _pos.y, _pos.z);
            if (transform.position.x > max || transform.position.x < min)
                speed *= -1;
        } 
    }

    private void OnMouseDown()
    {
        if(isclicked==1)
        GetComponent<MeshRenderer>().material.color = Color.black;
        else
            GetComponent<MeshRenderer>().material.color = Color.red;
        isclicked *= -1;
        Debug.Log("CliCked Object");
    }
}
