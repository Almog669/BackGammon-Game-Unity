﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SC_GlobalEnums : MonoBehaviour
{
   public enum Screens
    {
        MainMenu,Loading,MultiPlayer,Options,StudentInfo
    };
}
